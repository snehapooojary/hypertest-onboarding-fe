import "primereact/resources/themes/saga-blue/theme.css";
import "primereact/resources/primereact.min.css";
import "primeicons/primeicons.css";
export declare const Pricing: () => import("react/jsx-runtime").JSX.Element;
declare const Nav: () => import("react/jsx-runtime").JSX.Element;
export default Nav;
