import React from 'react';
import './index.css';
declare const Homepage: React.FC;
export default Homepage;
