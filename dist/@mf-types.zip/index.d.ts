export * from './compiled-types/pages/landing-page/index';
export { default } from './compiled-types/pages/landing-page/index';